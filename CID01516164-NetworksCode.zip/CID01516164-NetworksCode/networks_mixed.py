# -*- coding: utf-8 -*-
"""
Created on Wed Mar 24 10:27:00 2021

@author: isabe
"""

import random
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from scipy import signal

def model(Nf, m): 
    N=2*m+1
    k=np.zeros(Nf)
    kexp=m
    q=2/3       
    G=nx.Graph()
    for i in range(N):
        G.add_node(i)
        
    P=1#kexp/float(N-1)
    edges=[]
    for s in range(N):
        for t in range(s+1,N):
            if random.random() <P:
                G.add_edge(s,t)
                edges+=[(s,t)]
                k[s]+=1
                k[t]+=1
    
    t=0
    while N+t<Nf:
        G.add_node(N+t)
        for x in range(m):
            if random.random()>q:
                node=random.randint(0,N+t-1)
                G.add_edge(N+t,node)
                edges+=[(N+t,node)]
                k[N+t]+=1
                k[node]+=1
            
            else:
                edge=random.randint(0,len(edges)-2)
                if random.random()<0.5:
                    node=edges[edge][0]
                else:
                    node=edges[edge][1]
                G.add_edge(N+t,node)
                edges+=[(N+t,node)]
                k[N+t]+=1
                k[node]+=1
        t+=1
    return k, G
 

def logbin(data, scale, zeros = False):
    if scale < 1:
        raise ValueError('Function requires scale >= 1.')
    count = np.bincount(data)
    tot = np.sum(count)
    smax = np.max(data)
    if scale > 1:
        jmax = np.ceil(np.log(smax)/np.log(scale))
        if zeros:
            binedges = scale ** np.arange(jmax + 1)
            binedges[0] = 0
        else:
            binedges = scale ** np.arange(1,jmax + 1)
            # count = count[1:]
        binedges = np.unique(binedges.astype('uint64'))
        x = (binedges[:-1] * (binedges[1:]-1)) ** 0.5
        y = np.zeros_like(x)
        count = count.astype('float')
        for i in range(len(y)):
            y[i] = np.sum(count[binedges[i]:binedges[i+1]]/(binedges[i+1] - binedges[i]))
            # print(binedges[i],binedges[i+1])
        # print(smax,jmax,binedges,x)
        # print(x,y)
    else:
        x = np.nonzero(count)[0]
        y = count[count != 0].astype('float')
        if zeros != True and x[0] == 0:
            x = x[1:]
            y = y[1:]
    y /= tot
    x = x[y!=0]
    y = y[y!=0]
    return x,y

M=[1, 2, 4, 8, 16, 32]
outputx=[]
outputy = []
#m=3
run = 10
Nf = 5000
for m in M:
    ks = []
    for i in range(0, run):
        k, G = model(Nf, m)    
        k = list(k)
        ks = ks + [k]
    k_flat = [item for sublist in ks for item in sublist]
    kx, kprob = logbin(k_flat, 1.45)
    outputx = outputx + [kx]
    outputy = outputy + [kprob]
    #plt.loglog(kx, kprob,'.')

colours = ['b', 'g', 'r', 'y', 'grey', 'm']
for i in range(0, len(M)):
    plt.loglog(outputx[i], outputy[i], '+', color = colours[i], label = M[i])

plt.xlabel("k")
plt.ylabel("$p(k)$")
plt.legend()
plt.show()

#Nf =10000
#m=3
#k,G = model(Nf, m)
#X=np.arange(0,Nf,1)   
#k=signal.savgol_filter(k,101,3)
#plt.plot(X,k)
#plt.xlabel("N")
#plt.ylabel("k")
#plt.show()   
